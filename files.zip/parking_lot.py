# Program: Parking Lot System
# Description: Manages vehicle parking with slot tracking and fee calculation.
# Covers: Abstract classes, encapsulation, properties, inheritance,
#         __str__, static methods, and class variables.

from abc import ABC, abstractmethod

class Vehicle(ABC):
    def __init__(self, reg_no, owner):
        self._reg_no = reg_no
        self._owner = owner

    @property
    def reg_no(self):
        return self._reg_no

    @abstractmethod
    def vehicle_type(self):
        pass

    def __str__(self):
        return f"{self._reg_no} | {self._owner} | {self.vehicle_type()}"

class Car(Vehicle):
    def vehicle_type(self):
        return "Car"

class Bike(Vehicle):
    def vehicle_type(self):
        return "Bike"

class Slot:
    def __init__(self, slot_no):
        self._slot_no = slot_no
        self._vehicle = None

    @property
    def is_free(self):
        return self._vehicle is None

    def assign(self, vehicle: Vehicle):
        if not self.is_free:
            return f"Slot {self._slot_no} is already occupied."
        self._vehicle = vehicle
        return f"{vehicle.reg_no} parked at slot {self._slot_no}."

    def vacate(self):
        if self.is_free:
            return f"Slot {self._slot_no} is already empty."
        reg = self._vehicle.reg_no
        self._vehicle = None
        return f"{reg} left slot {self._slot_no}."

class ParkingLot:
    location = "Main Street"

    def __init__(self, total_slots):
        self.slots = [Slot(i+1) for i in range(total_slots)]

    def available_slots(self):
        return sum(1 for s in self.slots if s.is_free)

    @staticmethod
    def calculate_fee(hours, rate=20):
        return hours * rate

    @classmethod
    def update_location(cls, loc):
        cls.location = loc
        return f"Location updated to {loc}."

c = Car("KA01AB1234", "Alice")
b = Bike("KA02CD5678", "Bob")
lot = ParkingLot(3)
print(c)
print(lot.slots[0].assign(c))
print(lot.slots[1].assign(b))
print("Available slots:", lot.available_slots())
print("Fee for 3 hrs:", ParkingLot.calculate_fee(3))
print(lot.slots[0].vacate())
print(ParkingLot.update_location("West Avenue"))
