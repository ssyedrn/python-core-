# Program: School Management System
# Description: Handles students, teachers and subject enrollment in a school.
# Covers: Abstract classes, encapsulation, properties, inheritance,
#         __str__, __len__, static methods, and class methods.

from abc import ABC, abstractmethod

class Person(ABC):
    def __init__(self, name, person_id):
        self._name = name
        self._id = person_id

    @property
    def name(self):
        return self._name

    @abstractmethod
    def role(self):
        pass

    def __str__(self):
        return f"ID: {self._id} | Name: {self._name} | Role: {self.role()}"

class Student(Person):
    def __init__(self, name, person_id):
        super().__init__(name, person_id)
        self._subjects = []

    def role(self):
        return "Student"

    def enroll(self, subject):
        if subject in self._subjects:
            return f"Already enrolled in {subject}."
        self._subjects.append(subject)
        return f"{self._name} enrolled in {subject}."

    def __len__(self):
        return len(self._subjects)

class Teacher(Person):
    def __init__(self, name, person_id, subject):
        super().__init__(name, person_id)
        self._subject = subject

    def role(self):
        return "Teacher"

    def teach(self):
        return f"{self._name} is teaching {self._subject}."

class School:
    school_name = "Greenwood School"

    def __init__(self):
        self.students = []

    def admit(self, student: Student):
        self.students.append(student)
        return f"{student.name} admitted."

    @classmethod
    def update_name(cls, name):
        cls.school_name = name
        return f"School renamed to {name}."

    @staticmethod
    def notice():
        return "School will remain closed on Sunday."

s = Student("Alice", 301)
t = Teacher("Mr. Roy", 101, "Math")
school = School()
print(school.admit(s))
print(s.enroll("Math"))
print(s.enroll("Science"))
print("Subjects enrolled:", len(s))
print(t.teach())
print(School.update_name("Sunrise School"))
print(School.notice())
